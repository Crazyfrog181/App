# 🛒 Multi-Apartment Grocery Store (Monorepo)

This is a full-stack **multi-vendor, multi-apartment grocery store app**.  
Vendors can manage stock per apartment, customers can order only from vendors in their apartment, and fees are applied automatically.

---

## 🚀 One-Click Deployment

### Backend (Node.js + Express + MongoDB)
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

### Frontend (React)
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/import)

---

## ⚙️ MongoDB Atlas Setup (Free Cloud Database)
1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas).  
2. Create a free cluster.  
3. Under "Database Access", create a user with password.  
4. Under "Network Access", allow access from all IPs (0.0.0.0/0).  
5. Get your **connection string**, it will look like:  
   ```
   mongodb+srv://<username>:<password>@cluster0.mongodb.net/grocery
   ```

---

## 🔑 Environment Variables

### Backend (`.env` on Render)
```
MONGO_URI=your_mongo_uri_here
JWT_SECRET=supersecretstring
PORT=5000
```

### Frontend (Vercel Project Settings)
```
REACT_APP_API_BASE=https://your-backend.onrender.com
```

---

## 🗂 Repo Structure
```
/backend   -> Node.js + Express API
/frontend  -> React app
render.yaml
vercel.json
README.md
```

---

## ✅ Features
- Multi-apartment: customers & vendors linked by apartment ID
- Vendor product CRUD (stock, price updates)
- Customer cart & checkout (with ₹15 delivery fee + ₹10 platform fee)
- Orders routed only to vendors in the same apartment
- JWT authentication & role-based access
- Ready for cloud deployment (Render + Vercel + MongoDB Atlas)

---
